---
name: StellarX Submission
about: Submit SEP 7 Printable Payment QR for Print Media
title: "SEP 7 Printable Payment QR for Print Media"
labels: stellarx, submission
assignees: ""
---

## Project

SEP 7 Printable Payment QR for Print Media

## Idea Number

17

## Summary

SEP 7 Printable Payment QR for Print Media gives operators a shared settlement score trail, signed wallet actions, and a Soroban-backed release path that can be audited from dashboard to ledger.

## Stellar Usage

- Stellar testnet
- Soroban contract
- Freighter wallet
- Stellar SDK
- XLM/USDC SAC references
